import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;


public class Flights {

	/**
	 * @author mansoorAhmed
	 * @param String flight_code
	 * @return Returns all towers that the flight crosses, for a given row of data
	 * 
	 */
	public static ArrayList<String> fetchTowers(String flight_code) {
		Hashtable<String, Map<String, String>> myData = ReadFlightsData.getData();
		Map<String, String> myDataRow = myData.get(flight_code);
		ArrayList<String> towers = new ArrayList<String>();
		
		//We are assuming the first 6 data columns in Flights.xlsx to be constant,
		//these fixed columns will have all required data and rest of the columns will be variable number of towers
		for(int i=7; i<=myDataRow.size(); i++) {
			if (myDataRow.containsKey("Tower"+(i-6))){
				towers.add(myDataRow.get("Tower"+(i-6)));
			}
		}
		
		return towers;
	}
	
	/**
	 * @author mansoorAhmed
	 * @param ArrayList<String> towers
	 * @return Returns totalDistance travelled by a flight while crossing all the given towers
	 * 
	 */
	public static double distBetweenTowers(ArrayList<String> towers) {
		
		double longitude1 = 0;
		double latitude1 = 0;
		double longitude2 = 0;
		double latitude2 = 0;
		double distanceCalc = 0;
		double totalDistance = 0;
		
		for (int i=0; i<towers.size()-1; i++) {
			String tower1 = towers.get(i);
			//fetch the longitude and latitude details for these tower locations
			//As of now, I have assumed that we will specify longitude and latitude in decimals in the excel, 
			//In the future we can create a method to covert the latitude and longitude to decimals 
			//by implementing a method with this formula: Decimal Degrees = Degrees + minutes/60 + seconds/3600
			
			Hashtable<String, Map<String, String>> data = ReadAirportsData.getData();
			Map<String, String> row1 = data.get(tower1);
			
			latitude1 = Double.parseDouble(row1.get("Latitude"));
			longitude1 = Double.parseDouble(row1.get("Longitude"));
			
			String tower2 = towers.get(i+1);
			Map<String, String> row2 = data.get(tower2);
			latitude2 = Double.parseDouble(row2.get("Latitude"));
			longitude2 = Double.parseDouble(row2.get("Longitude"));
			
			distanceCalc = CommonMethods.distance(latitude1, longitude1, latitude2, longitude2);
			totalDistance += distanceCalc;
		}
				
		return totalDistance;
	}
	
	/*
	 * public void addFlights(String airline, String typeOfAirline, int uniqueCode,
	 * String departure, String destination, String depDate, String depTime,
	 * ArrayList<String> Towers) { //Get the details entered on the UI by the user
	 * and pass on the details to DB/File }
	 */
	
	/**
	 * @author mansoorAhmed
	 * @param ArrayList<String> towers
	 * @return Returns a double which is an average distance travelled by the flight
	 * 
	 */
	public double averageDistanceTravelled(ArrayList<String> towers) {
		double avgDistance = 0;
		double totalDistance = distBetweenTowers(towers);
		avgDistance = totalDistance/(towers.size());
		return avgDistance;
	}
	
	/*
	 * public static void main(String[] args) {
	 * 
	 * System.out.println(timeTravelled(228.5368,"DC6"));
	 * 
	 * }
	 */
	
}
