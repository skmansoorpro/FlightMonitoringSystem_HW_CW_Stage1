import java.io.IOException;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @author mansoorAhmed
 * Utility to read excel file, row by row, according to the code (first column in excel)
 */
public class ReadFlightsData {
	
	private static XSSFWorkbook workbook = null;
	private static final Logger log = LogManager.getLogger(ReadFlightsData.class);
	static XSSFSheet sheet = null;
	
	/**
	 * @author mansoorAhmed
	 * @param none
	 * @return Map<String, Object>, where String is the primary key (code) and Object contains the row for that code as represented in the excel file.
	 * @throws IOException 
	 * 
	 */
	public static Hashtable<String, Map<String, String>> getData() {
		
		try {

			//String projectPath = System.getProperty("user.dir");
			workbook = new XSSFWorkbook("/Users/mansoorahmed/Desktop/HW/ASE_Final/excel_files/Flights.xlsx");
			sheet = workbook.getSheet("Sheet1");

			log.info("Started reading the excel file.");

			} catch (Exception e) {
		
				e.getMessage();
				e.getCause();
				log.debug("Exception found while creating the worksheet for excel file: " + e.getMessage());

			}
		
		Hashtable<String, Map<String, String>> rowMap = new Hashtable<String, Map<String, String>>();
		
		List<Map<String, String>> temp = new LinkedList<Map<String, String>>();
		
		try {
			
			int rowCount = sheet.getPhysicalNumberOfRows();	
			int columns = sheet.getRow(0).getLastCellNum();

			for (int i = 1; i < rowCount; i++) {
				Map<String, String> row = new LinkedHashMap<String, String>();
				for (int j = 0; j < columns; j++) {
					if (sheet.getRow(i).getCell(j)==null) {
						break;
					} else {
						row.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i).getCell(j).toString());
					}
				}
				temp.add(row);
			}
			
			Map<String, String> tempMap = new LinkedHashMap<String, String>();
			for (int k = 1; k < rowCount; k++) {
				tempMap = temp.get(k-1);
				if(sheet.getRow(k).getCell(0).toString().equalsIgnoreCase(tempMap.get("flight_code").toString())){
					rowMap.put(sheet.getRow(k).getCell(0).toString(), temp.get(k-1));
				}
			}

		} catch (Exception e) {
		
			e.getMessage();
			e.getCause();
			log.debug("Exception found while reading excel file: " + e.getMessage());
	
		}

		log.info("Completed reading the excel file and returning the Map containing the data.");
		try {
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return rowMap;
		
		
	}
	
	
	/*
	 * public static void main(String[] args) throws IOException {
	 * 
	 * Map<String, Map<String, String>> myData = ReadFlightsData.getData();
	 * System.out.println(myData);
	 * 
	 * }
	 */
	
}
