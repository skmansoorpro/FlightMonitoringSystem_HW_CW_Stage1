import java.util.Map;

public class Aeroplanes {
	
	/**
	 * @author mansoorAhmed
	 * @param double distanceTravelled
	 * @param String aeroplaneModel
	 * @return Returns time taken to travel total distance(Kms) in minutes
	 * 
	 */
	public static double timeTravelled(double distanceTravelled, String aeroplaneModel) {
		double time = 0.0;
		
		//fetch the speed of the given aeroplane from aeroplane data
		Map<String,Map<String, String>> aeroplaneData = ReadAeroplaneData.getData();
		double speed = Double.parseDouble(aeroplaneData.get(aeroplaneModel).get("Speed"));
		
		//time = distance/speed
		time = (distanceTravelled/speed)*60;
		return time;
	}
	
	/**
	 * @author mansoorAhmed
	 * @param double distanceTravelled and String aeroplaneModel
	 * @return Returns time taken to travel total distance(Kms) in minutes
	 * 
	 */
	public static double totalFuelConsumption(double distanceTravelled, String aeroplaneModel) {
		//fuel consumed is in --- liters per 100km
		//fetch the fuel consumed for the given aeroplane model
		Map<String,Map<String, String>> aeroplaneData = ReadAeroplaneData.getData();
		double fuelConsumed = Double.parseDouble(aeroplaneData.get(aeroplaneModel).get("Consumption"));
		double totalFuelConsumed = (distanceTravelled*fuelConsumed)/100;
		return totalFuelConsumed;
	}
	
	/**
	 * @author mansoorAhmed
	 * @param distanceTravelled
	 * @param aeroplaneModel
	 * @return Returns CO2Emission of the given aeroplane model by considering the total distance travelled
	 */
	public static double co2Emission(double distanceTravelled, String aeroplaneModel) {
		int cons = 6;
		double totalFuel = totalFuelConsumption(distanceTravelled,aeroplaneModel);
		double co2Emmition = totalFuel*cons;	
		return co2Emmition;
	}
	
	/*
	 * public static void main(String[] args) {
	 * System.out.println(timeTravelled(228.5368,"DC6")); }
	 */
}
