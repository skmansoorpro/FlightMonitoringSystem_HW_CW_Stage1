
import javax.swing.*;

import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JComboBox;
import javax.swing.ListCellRenderer;

import java.awt.*;

public class FMS_GUI_Others extends JFrame{
	


    FMS_GUI_Others(){
    	
    	
        setTitle("Flight Monitoring System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        
        //setting the bounds for the JFrame
        setBounds(100,100,645,470);
        Border br = BorderFactory.createLineBorder(Color.BLUE);
        Container c=getContentPane();
        
        //Creating a JPanel for the JFrame
        JPanel panel1=new JPanel(new BorderLayout());
        JPanel panel2=new JPanel(new BorderLayout());
        JPanel panel3=new JPanel(new BorderLayout());
        JPanel panel4=new JPanel(new BorderLayout());
        JPanel panel5=new JPanel(new BorderLayout());
        JPanel panel6=new JPanel(new BorderLayout());
        JPanel panel7=new JPanel(new BorderLayout());
        JPanel panel8=new JPanel(new BorderLayout());
        
        //Display Distance travelled by the flight AF670
        String flight_code = "AF670";
        ArrayList<String> towers = Flights.fetchTowers(flight_code);
        double totalDist = Flights.distBetweenTowers(towers);
        String totDist = String.valueOf(totalDist);
        Label l5=new Label("Distance in KMs");
        TextField t5=new TextField();
        t5.setText(totDist);
        l5.setBounds(800,40,100,50);
        
        //Display total time travelled by the flight, Aeroplane model A350 --> to get the speed
        String aeroplaneModel = "A350";
        double totalTime = Aeroplanes.timeTravelled(totalDist, aeroplaneModel);
        String totTime = String.valueOf(totalTime);
        Label l6=new Label("Time in minutes");
        TextField t6=new TextField();
        t6.setText(totTime);
        l6.setBounds(800,100,100,50);
        
        //Display the fuel consumption in Liters for the flight
        double totalFuelConsumed = Aeroplanes.totalFuelConsumption(totalTime, aeroplaneModel);
        Label l7=new Label("Fuel Consumption in Litres");
        TextField t7=new TextField();
        String totFuel = String.valueOf(totalFuelConsumed);
        t7.setText(totFuel);
        l7.setBounds(800,200,100,50);
        
        //Display the CO2 Emmission for the flight
        double co2Emmitted = Aeroplanes.co2Emission(totalFuelConsumed, aeroplaneModel);
        Label l8=new Label("CO2 in KGs");
        TextField t8=new TextField();
        String totalCO2 = String.valueOf(co2Emmitted);
        t8.setText(totalCO2);
        l8.setBounds(800,300,100,50);
     
        //setting the panel layout as null
        
        /*
        panel1.setLayout(null);
        panel2.setLayout(null);
        panel3.setLayout(null);
        panel4.setLayout(null);
*/
        
        
        //adding a label element to the panel
        JLabel label1=new JLabel("Panel 1");
        JLabel label2=new JLabel("Panel 2");
        JLabel label3=new JLabel("https://www.coderanch.com/t/337745/java/Howto-load-JComboBox-list-Hashtable");
        JLabel label4=new JLabel("https://www.coderanch.com/t/337745/java/Howto-load-JComboBox-list-Hashtable");
        JLabel label5=new JLabel("Panel 5");
        JLabel label6=new JLabel("Panel 6");
        JLabel label7=new JLabel("Panel 7");
        JLabel label8=new JLabel("Panel 8");



       // label1.setBounds(120,50,200,50);
        //label2.setBounds(120,50,200,50);
        //label3.setBounds(120,50,200,50);
        //label4.setBounds(120,50,200,50);
        
        //panel1.add(label1);
        //panel2.add(label2);
       // panel3.add(label3);
        //panel4.add(label4);
        
        panel5.add(label5);
        panel5.add(t5);

        panel6.add(label6);
        panel6.add(t6);
        
        panel7.add(label7);
        panel7.add(t7);
        
        panel8.add(label8);
        panel8.add(t8);
        


        // changing the background color of the panel to yellow

        //Panel 1
        //panel1.setBackground(Color.gray);
        panel1.setBounds(10,20,400,200);
        
panel1.setBorder(BorderFactory.createTitledBorder( BorderFactory.createEtchedBorder(), "FLIGHTS", TitledBorder.LEFT, TitledBorder.TOP));

//Below code fetches the data from flight datasheet and converts the data to rows and columns to display in the UI
	int row = 0;
	int col = 0;
    
	//Columns to be displayed are constant
    String[] header = { "Flight_Code", "Plane_Code", "Departure","Destination","Date","Time","Tower1","Tower2","Tower3","Tower4","Tower5"};
	col = header.length;
	
	//Fetch the Flight data
	Hashtable<String, Map<String, String>> flightsData = ReadFlightsData.getData();
	row = flightsData.size();
	//Create a two dimensional array to pass the row data to jTable
	String[][] rowArray = new String[row][col];
	int r = 0;
	
	//Fetch the rows containing flight data from the Hashtable
 	for(Entry<?, ?> entry: flightsData.entrySet())	 { 
 		@SuppressWarnings("unchecked")
 		Map<String, String> rowMap = (Map<String, String>) entry.getValue();
 		ArrayList<String> rowList = new ArrayList<String>();
 		
 		//Add the row data into an ArrayList
 		 for(Entry<?, ?> rowEntry: rowMap.entrySet()) {
 			rowList.add(rowEntry.getValue().toString());
 			//System.out.println(rowEntry.getValue().toString());
 		 }
 		 //Add each element of the arrayList to the 2D array
	     for (int c1=0; c1<col; c1++) {
	    	if(c1>=rowList.size()) {
		    	rowArray[r][c1]=" ";
		    	System.out.println(rowArray[r][c1]);
	    	} else {
		    	rowArray[r][c1]=rowList.get(c1).toString();
		    	//System.out.println(rowList.get(c1).toString());
	    	}
	    	//System.out.println(rowArray.length);

	     }
		 r++;
  	}
     
 	//Pass the Rows (2D Array) and the Header Columns to jTable to display on UI
     JTable table = new JTable(rowArray, header);
     table.setGridColor(Color.BLUE);
     table.setShowHorizontalLines(true);
     table.setShowVerticalLines(true);
     Color gray=new Color(199,199,199);
     table.setOpaque(false);
     table.setBackground(gray);
     table.getTableHeader().setBackground(Color.YELLOW);


     

     panel1.add(new JScrollPane(table));

     //frame.setSize(550, 400);
     //frame.setVisible(true);
     //panel.setBounds(10,10,300,300);
    
     
        //Panel 2
     
        panel2.setBounds(450,20,100,200);
        panel2.setBorder(BorderFactory.createTitledBorder( BorderFactory.createEtchedBorder(), "PLANS", TitledBorder.LEFT, TitledBorder.TOP));
     String[][] rec2 = {
        {"LLG"},
        {"qqG"},
        {"ffG"},
        {"eeG"},
        {"aaG"}
     };
     String[] header2 = {"Plan"};
     JTable table2 = new JTable(rec2, header2);
     panel2.add(new JScrollPane(table2));
     table2.setGridColor(Color.BLUE);
     table2.setShowHorizontalLines(true);
     table2.setShowVerticalLines(true);
    // Color ivory=new Color(255,255,208);
     table2.setOpaque(false);
     table2.setBackground(gray);
     table2.getTableHeader().setBackground(Color.YELLOW);


        //Panel 3
        panel3.setBorder(BorderFactory.createTitledBorder( BorderFactory.createEtchedBorder(), "ADD FLIGHT", TitledBorder.LEFT, TitledBorder.TOP));
        panel3.setBounds(10,230,550,40);
        
        
       String[][] rec3 = {
    	        { "Air France", "001","A350","DBX","SYD","10/01/2022","2230" }
};
        
	     String[] header3 = { "Airline", "Number","Plane", "Departure","Destination","Date","Time" };
	     JTable table3 = new JTable(rec3, header3);
	     table3.setGridColor(Color.BLUE);
	     table3.setShowHorizontalLines(true);
	     table3.setShowVerticalLines(true);
	     table3.setOpaque(false);
	     table3.setBackground(gray);
	     table3.getTableHeader().setBackground(Color.YELLOW);
	     panel3.add(new JScrollPane(table3));

     

        //Panel 4
        panel4.setBounds(10,300,550,40);
        panel4.setBorder(BorderFactory.createTitledBorder( BorderFactory.createEtchedBorder(), "SELECT FLIGHT PLAN", TitledBorder.LEFT, TitledBorder.TOP));
        
        
       String[][] rec4 = {
    	        {"CDG","FKF","BCH","THR","AUH"}
       				};
        
	     String[] header4 = { "Tower 1","Tower 2","Tower 3","Tower 4","Tower 5"};
	     JTable table4 = new JTable(rec4, header4);
	     table4.setGridColor(Color.BLUE);
	     table4.setShowHorizontalLines(true);
	     table4.setShowVerticalLines(true);
	     table4.setOpaque(false);
	     table4.setBackground(gray);
	     table4.getTableHeader().setBackground(Color.YELLOW);
	     panel4.add(new JScrollPane(table4));

        
        
     
       
        //Panel 5
        panel5.setBorder(BorderFactory.createTitledBorder( BorderFactory.createEtchedBorder(), "Distance in KMs", TitledBorder.LEFT, TitledBorder.TOP));

        panel5.setBackground(Color.yellow);
        panel5.setBounds(650,20,125,50);
        
        
        //Panel 6
        panel6.setBorder(BorderFactory.createTitledBorder( BorderFactory.createEtchedBorder(), "Time", TitledBorder.LEFT, TitledBorder.TOP));

        
        panel6.setBackground(Color.yellow);
        panel6.setBounds(650,100,100,50);
        
        //Panel 7
        
        panel7.setBorder(BorderFactory.createTitledBorder( BorderFactory.createEtchedBorder(), "Fuel in Litres", TitledBorder.LEFT, TitledBorder.TOP));

       
        panel7.setBackground(Color.yellow);
        panel7.setBounds(650,200,100,50);
        
        //Panel 8
        
        panel8.setBorder(BorderFactory.createTitledBorder( BorderFactory.createEtchedBorder(), "CO2 KGs", TitledBorder.LEFT, TitledBorder.TOP));

        
        panel8.setBackground(Color.yellow);
        panel8.setBounds(650,300,100,50);
        
        


      
        

        // Panel border
        panel1.setBorder(br);
        panel2.setBorder(br);
        panel3.setBorder(br);
        panel4.setBorder(br);
        
        
        //adding the panel to the Container of the JFrame
        c.add(panel1);
        c.add(panel2);
        c.add(panel3);
        c.add(panel4);
        c.add(panel5);
        
        c.add(panel5);
        c.add(panel6);
        c.add(panel7);
        c.add(panel8);
        

       

        setVisible(true);
    }
    public static void main(String[] args) {
        new FMS_GUI_Others();
        

    }

}