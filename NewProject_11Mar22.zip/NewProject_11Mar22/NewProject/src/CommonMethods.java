public class CommonMethods {

	/*
	 * public static double distance(double latitude1, double longitude1, double
	 * latitude2, double longitude2) { int earthRadius = 6371; double
	 * radian_latitude1 = 0; double radian_longitude1 = 0; double radian_latitude2 =
	 * 0; double radian_longitude2 = 0; double delta_latitude = 0; double
	 * delta_longitude = 0; double trigo = 0; double distanceCalculated = 0;
	 * 
	 * radian_latitude1 = latitude1 * (Math.PI/180); radian_longitude1 = longitude1
	 * * (Math.PI/180); radian_latitude2 = latitude2 * (Math.PI/180);
	 * radian_longitude2 = longitude2 * (Math.PI/180); delta_latitude =
	 * radian_latitude2 - radian_latitude1; delta_longitude = radian_longitude2 -
	 * radian_longitude1; trigo = Math.sin(delta_latitude/2) + Math.cos(latitude1) *
	 * Math.cos(latitude2) * Math.sin(delta_longitude/2); distanceCalculated = 2 *
	 * earthRadius * Math.asin(Math.sqrt(trigo));
	 * 
	 * return distanceCalculated; }
	 */

	//Returns distance between two locations in Kilometres
	public static double distance(double latitude1, double longitude1, double latitude2, double longitude2) {
		
		double x1 = Math.toRadians(latitude1);
		double y1 = Math.toRadians(longitude1);
		double x2 = Math.toRadians(latitude2);
		double y2 = Math.toRadians(longitude2);

		/*************************************************************************
		 * Compute using law of cosines
		 *************************************************************************/
		// great circle distance in radians
		double angle = Math.acos(Math.sin(x1) * Math.sin(x2) + Math.cos(x1) * Math.cos(x2) * Math.cos(y1 - y2));

		// convert back to degrees
		angle = Math.toDegrees(angle);

		// each degree on a great circle of Earth is 60 nautical miles
		double distance = 60 * angle;
		//Converting distance from nautical miles to Kilometers
		distance = distance*1.852;
		
		return distance;
	}

	/*
	 * public static void main(String[] args) {
	 * 
	 * System.out.println(distance(48.864716, 2.349014, 37.615223, -122.389977));
	 * 
	 * }
	 */

}
