import static org.junit.Assert.*;

import org.junit.Test;

public class CommonMethodsTest {

	public CommonMethods undertest = new CommonMethods();
	@Test
	public void testDistancepos() {

		double latitude1 = 19.097403;
		double longitude1 = 72.874245;
		
		double latitude2 = 19.097403;
		double longitude2 = 72.874245;
		
		double distance = CommonMethods.distance(latitude1,longitude1,latitude2,longitude2);
		
		String distance_string = String.valueOf(distance);
		assertEquals("0.0", distance_string);
	}

}
