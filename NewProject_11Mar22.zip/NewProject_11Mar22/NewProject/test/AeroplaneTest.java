import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.notification.Failure;

/**
 * 
 */

/**
 * @author mansoorahmed
 *
 */
public class AeroplaneTest {

	public Aeroplanes undertest = new Aeroplanes();
	
	/**
	 * Test method for {@link Aeroplanes#timeTravelled(double, java.lang.String)}.
	 */
	@Test
	public void testTimeTravelledPos() {
		
		double distanceTravelled = 1000;
		String aeroplaneModel = "A350";
		double timeTravelled = Aeroplanes.timeTravelled(distanceTravelled, aeroplaneModel);
		
		String timeTravel = String.valueOf(timeTravelled);
		assertEquals("66.66666666666667", timeTravel);
	}
	
	/**
	 * Test method for {@link Aeroplanes#timeTravelled(double, java.lang.String)}.
	 */
	@Test
	public void testTimeTravelledNeg() {
		
		double distanceTravelled = 1000;
		String aeroplaneModel = "A350";
		double timeTravelled = Aeroplanes.timeTravelled(distanceTravelled, aeroplaneModel);
		
		String timeTravel = String.valueOf(timeTravelled);
		assertEquals("60", timeTravel);
	}

	/**
	 * Test method for {@link Aeroplanes#totalFuelConsumption(double, java.lang.String)}.
	 */
	@Test
	public void testTotalFuelConsumptionNeg() {
		//fail("Not yet implemented");
		
		double distanceTravelled = 1000;
		String aeroplaneModel = "A350";
		double totalFuelConsumed = Aeroplanes.totalFuelConsumption(distanceTravelled, aeroplaneModel);
		
		String totalFuelConsumption = String.valueOf(totalFuelConsumed);
		assertEquals("1100", totalFuelConsumed);
		
	}

	/**
	 * Test method for {@link Aeroplanes#co2Emission(double, java.lang.String)}.
	 */
	@Test
	public void testCo2EmissionNeg() {
		//fail("Not yet implemented");
		
		double distanceTravelled = 1000;
		String aeroplaneModel = "A350";
		double co2Emmition = Aeroplanes.co2Emission(distanceTravelled, aeroplaneModel);
		
		String totalFuelConsumption = String.valueOf(co2Emmition);
		assertEquals("1100", co2Emmition);
		
	}

}
